const db = require('../config/db');

exports.getAllCustomerOrders = async (req, res) => {
    try {
        // Fetch all orders with customer details
        const ordersQuery = `
            SELECT 
                co.order_id, 
                co.customer_id, 
                co.order_date, 
                co.total_price, 
                co.status,
                c.first_name,
                c.last_name,
                c.email,
                c.address as shipping_address
            FROM customer_orders co
            JOIN Customers c ON co.customer_id = c.customer_id
            ORDER BY co.order_date DESC
        `;
        const [orders] = await db.query(ordersQuery);

        if (orders.length === 0) {
            return res.status(200).json([]);
        }

        const validOrders = orders.map(o => ({
            ...o,
            customer_name: `${o.first_name} ${o.last_name}`,
            items: []
        }));

        const orderIds = validOrders.map(o => o.order_id);
        const itemsQuery = `
            SELECT 
                oi.order_id, 
                oi.isbn, 
                oi.quantity, 
                oi.price, 
                b.Title as title,
                p.Name as publisher,
                GROUP_CONCAT(a.Name SEPARATOR ', ') as authors
            FROM order_items oi
            JOIN Books b ON oi.isbn = b.ISBN
            LEFT JOIN Publishers p ON b.publisher_id = p.publisher_id
            LEFT JOIN BookAuthors ba ON b.ISBN = ba.isbn
            LEFT JOIN Authors a ON ba.author_id = a.author_id
            WHERE oi.order_id IN (?)
            GROUP BY oi.order_id, oi.isbn
        `;

        const [items] = await db.query(itemsQuery, [orderIds]);

        // Map items to orders
        const ordersMap = {};
        validOrders.forEach(o => ordersMap[o.order_id] = o);

        items.forEach(item => {
            if (ordersMap[item.order_id]) {
                // Transform authors string to array
                const itemWithAuthors = {
                    ...item,
                    authors: item.authors ? item.authors.split(', ') : []
                };
                ordersMap[item.order_id].items.push(itemWithAuthors);
            }
        });

        return res.status(200).json(Object.values(ordersMap));

    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
};

exports.updateCustomerOrderStatus = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body; // 'Pending', 'Shipped', 'Delivered', 'Cancelled'

        if (!status) return res.status(400).json("Status is required.");

        await db.query("UPDATE customer_orders SET status = ? WHERE order_id = ?", [status, id]);

        return res.status(200).json("Order status updated successfully.");
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
};

exports.getLowStockBooks = async (req, res) => {
    try {
        const [books] = await db.query(`
            SELECT Books.*, Publishers.Name as publisher, GROUP_CONCAT(Authors.Name SEPARATOR ', ') as authors 
            FROM Books 
            LEFT JOIN Publishers ON Books.publisher_id = Publishers.publisher_id
            LEFT JOIN BookAuthors ON Books.ISBN = BookAuthors.isbn
            LEFT JOIN Authors ON BookAuthors.author_id = Authors.author_id
            WHERE Stock < Threshold
            GROUP BY Books.ISBN
        `);
        const mappedBooks = books.map(b => ({
            ...b,
            authors: b.authors ? b.authors.split(', ') : []
        }));
        return res.status(200).json(mappedBooks);
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
};

exports.getAllPublisherOrders = async (req, res) => {
    try {
        const [orders] = await db.query(`
            SELECT 
                po.order_id as id,
                po.isbn,
                b.Title as title,
                p.Name as publisher,
                po.quantity as orderQuantity,
                po.status,
                po.order_date as date,
                GROUP_CONCAT(Authors.Name SEPARATOR ', ') as authors
            FROM publisher_orders po
            JOIN Books b ON po.isbn = b.ISBN
            LEFT JOIN Publishers p ON b.publisher_id = p.publisher_id
            LEFT JOIN BookAuthors ON b.ISBN = BookAuthors.isbn
            LEFT JOIN Authors ON BookAuthors.author_id = Authors.author_id
            GROUP BY po.order_id
            ORDER BY po.order_date DESC
        `);
        const mappedOrders = orders.map(o => ({
            ...o,
            authors: o.authors ? o.authors.split(', ') : []
        }));
        return res.status(200).json(mappedOrders);
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
};

exports.placePublisherOrder = async (req, res) => {
    try {
        const { isbn, quantity } = req.body;

        // Find publisher for the book
        const [book] = await db.query("SELECT publisher_id FROM Books WHERE ISBN = ?", [isbn]);
        if (book.length === 0) return res.status(404).json("Book not found.");

        const publisherId = book[0].publisher_id;

        await db.query(
            "INSERT INTO publisher_orders (isbn, publisher_id, quantity, status, order_date) VALUES (?, ?, ?, 'Pending', NOW())",
            [isbn, publisherId, quantity]
        );

        return res.status(201).json("Restock order placed successfully.");
    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
};

exports.confirmPublisherOrder = async (req, res) => {
    try {
        const { id } = req.params;

        const connection = await db.getConnection();

        try {
            // Start transaction
            await connection.beginTransaction();

            const [order] = await connection.query("SELECT * FROM publisher_orders WHERE order_id = ? AND status = 'Pending'", [id]);
            if (order.length === 0) {
                await connection.rollback();
                return res.status(404).json("Order not found or already confirmed.");
            }

            const { isbn, quantity } = order[0];

            // Update order status
            await connection.query("UPDATE publisher_orders SET status = 'Received' WHERE order_id = ?", [id]);

            // Update book stock
            await connection.query("UPDATE Books SET Stock = Stock + ? WHERE ISBN = ?", [quantity, isbn]);

            await connection.commit();
            return res.status(200).json("Order confirmed and stock updated.");

        } catch (innerErr) {
            await connection.rollback();
            throw innerErr;
        } finally {
            connection.release();
        }

    } catch (err) {
        return res.status(500).json({ error: err.message });
    }
};
